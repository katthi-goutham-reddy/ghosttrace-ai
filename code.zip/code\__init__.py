"""GhostTrace AI package."""
